<?php
/**
 * Plugin Name: Update Stores after CSV Import
 * Description: After importing WPSL stores through a CSV, use this plugin to automatically add LAT and LONG values.
 * Version: 1.0
 * Author: Jordan Webdev
 * Author URI: www.jordanwebdev.com
 */

add_action('admin_menu', 'jwd_update_all_stores_menu');

function jwd_update_all_stores_menu()
{
    add_menu_page('Update Stores', 'Update Stores', 'manage_options', 'jwd-update-all-stores', 'jwd_update_all_stores_admin_page');
}

function jwd_update_all_stores_admin_page()
{

  // This function creates the output for the admin page.
  // It also checks the value of the $_POST variable to see whether
  // there has been a form submission.

  // The check_admin_referer is a WordPress function that does some security
  // checking and is recommended good practice.

  // General check for user permissions.
  if (!current_user_can('manage_options')) {
      wp_die(__('You do not have sufficient priviledges to access this page.'));
  }

  // Start building the page

  echo '<div class="wrap">';

    echo '<h2>Automatically insert Lat and Long in all stores</h2>';

  // Check whether the button has been pressed AND also check the nonce
  if (isset($_POST['jwd_update_all_stores_button']) && check_admin_referer('jwd_update_all_stores_button_clicked')) {
      // the button has been pressed AND we've passed the security check
    jwd_update_all_stores_action();
  }

    echo '<form action="options-general.php?page=jwd-update-all-stores" method="post">';

  // this is a WordPress security feature - see: https://codex.wordpress.org/WordPress_Nonces
  wp_nonce_field('jwd_update_all_stores_button_clicked');
    echo '<input type="hidden" value="true" name="jwd_update_all_stores_button" />';
    submit_button('Update Stores');
    echo '</form>';

    echo '</div>';
}

function jwd_update_all_stores_action()
{
    echo '<div id="message" class="updated fade"><p>'
    .'All Stores have had their lat and long values set.' . '</p></div>';


    $posts = get_posts( array('post_type' => 'wpsl_stores', 'numberposts' => -1 ) );

    foreach ( $posts as $post ):

      //$my_post->post_content = 'This is the updated content.';

      $id = $post->ID;
      $long = get_post_meta($id, 'wpsl_lng', true);
      $lat = get_post_meta($id, 'wpsl_lat', true);

      $address = '111 zenyway blvd, vaughan, ON'; // Google HQ
      $prepAddr = str_replace(' ','+',$address);
      $geocode=file_get_contents('https://maps.google.com/maps/api/geocode/json?address='.$prepAddr.'&sensor=false');
      $output= json_decode($geocode);
      $new_lat = $output->results[0]->geometry->location->lat;
      $new_long = $output->results[0]->geometry->location->lng;



      update_post_meta( $id, 'wpsl_lng', $new_long );
      update_post_meta( $id, 'wpsl_lat', $new_lat );


    endforeach;
}
